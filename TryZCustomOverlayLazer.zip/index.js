let jsonData = {
    leaderboardEnable: 1,
    leaderboardTab: 0,
};

async function readJSON() {
    try {
        jsonData = await $.getJSON("config.json");
    } catch (error) {
        console.error("Could not read JSON file", error);
    }
}
readJSON();

// START
let socket = new ReconnectingWebSocket("ws://127.0.0.1:24050/ws");
let mapid = document.getElementById("mapid");
let mapBG = document.getElementById("mapBG");
let rankingPanelBG = document.getElementById("rankingPanelBG");
let recorder = document.getElementById("recorder");
let recorderName = document.getElementById("recorderName");
let resultRecorder = document.getElementById("resultRecorder");

// NOW PLAYING
let mapContainer = document.getElementById("nowPlayingContainer");
let mapTitle = document.getElementById("mapTitle");
let mapDesc = document.getElementById("mapDesc");
let stars = document.getElementById("stars");
let starsCurrent = document.getElementById("starsCurrent");
let overlay = document.getElementById("overlay");

// PLAYING SCORE
let upperPart = document.getElementById("top");
let score = document.getElementById("score");
let acc = document.getElementById("acc");
let combo = document.getElementById("combo");

// ACCURACY INFO
let bottom = document.getElementById("bottom");
let lowerPart = document.getElementById("lowerPart");
let accInfo = document.getElementById("accInfo");
let h300 = document.getElementById("h300");
let h100 = document.getElementById("h100");
let h50 = document.getElementById("h50");
let h0 = document.getElementById("h0");

// PERFORMANCE POINTS
let pp = document.getElementById("pp");

// PLAYER INFO
let username = document.getElementById("username");
let country = document.getElementById("country");
let ranks = document.getElementById("ranks");
let countryRank = document.getElementById("countryRank");
let playerPP = document.getElementById("playerPP");

let tickLeft = document.getElementById("tickLeft");
let tickRight = document.getElementById("tickRight");

// HP BAR
let hp = document.getElementById("hp");

let progressChart = document.getElementById("progress");
let strainGraph = document.getElementById("strainGraph");

// UR

let URbar = document.getElementById("URbar");
let URtick = document.getElementById("URtick");
let avgHitError = document.getElementById("avgHitError");

let l300 = document.getElementById("l300");
let l100 = document.getElementById("l100");
let URIndex = document.getElementById("URIndex");

let leaderboard = document.getElementById("leaderboard");

// Ranking Result
let rankingPanel = document.getElementById("rankingPanel");

let mapContainerR = document.getElementById("mapContainer");
let rankedStatus = document.getElementById("rankedStatus");
let mapArtistTitle = document.getElementById("mapArtistTitle");
let mapDifficulty = document.getElementById("mapDifficulty");
let mapCreator = document.getElementById("mapCreator");

let statSection = document.getElementById("statSection");
let rCS = document.getElementById("CS");
let rAR = document.getElementById("AR");
let rOD = document.getElementById("OD");
let rHP = document.getElementById("HD");
let rSR = document.getElementById("SR");

let player = document.getElementById("player");
let playerAva = document.getElementById("playerAva");
let playerCountry = document.getElementById("playerCountry");
let playerName = document.getElementById("playerName");
let playerPerformance = document.getElementById("playerPerformance");
let playerRank = document.getElementById("playerRank");
let playerCRank = document.getElementById("playerCRank");

let rankingResult = document.getElementById("rankingResult");

let result = document.getElementById("result");
let scoreResult = document.getElementById("scoreResult");
let comboResult = document.getElementById("comboResult");
let accResult = document.getElementById("accResult");
let URResult = document.getElementById("URResult");

let r300 = document.getElementById("r300");
let r100 = document.getElementById("r100");
let r50 = document.getElementById("r50");
let r0 = document.getElementById("r0");

let ppResult = document.getElementById("ppResult");
let globalColor;
let graphRaw;

socket.onopen = () => {
    console.log("Successfully Connected");
};

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

let animation = {
    acc: new CountUp("acc", 0, 0, 2, 0.2, {
        useEasing: true,
        useGrouping: false,
        separator: " ",
        decimal: ".",
        suffix: "% - UR:",
    }),
    URIndex: new CountUp("URIndex", 0, 0, 2, 0.2, {
        useEasing: true,
        useGrouping: false,
        separator: " ",
        decimal: ".",
        suffix: "",
    }),
    score: new CountUp("score", 0, 0, 0, 0.2, {
        useEasing: true,
        useGrouping: true,
        separator: "",
        decimal: ".",
    }),
    combo: new CountUp("combo", 0, 0, 0, 0.2, {
        useEasing: true,
        useGrouping: true,
        separator: "",
        decimal: ".",
        suffix: "x",
    }),
    starsCurrent: new CountUp("starsCurrent", 0, 0, 2, 0.2, {
        useEasing: true,
        useGrouping: true,
        separator: " ",
        decimal: ".",
        prefix: "Now: ",
        suffix: "*",
    }),
    stars: new CountUp("stars", 0, 0, 2, 0.2, {
        useEasing: true,
        useGrouping: true,
        separator: " ",
        decimal: ".",
        prefix: "Full: ",
        suffix: "*",
    }),
    pp: new CountUp("pp", 0, 0, 0, 0.2, {
        useEasing: true,
        useGrouping: true,
        separator: " ",
        decimal: ".",
        suffix: "pp",
    }),
    ourplayerScore: new CountUp("ourplayerScore", 0, 0, 0, 0.2, {
        useEasing: true,
        useGrouping: true,
        separator: ",",
        decimal: ".",
    }),
};

socket.onclose = (event) => {
    console.log("Socket Closed Connection: ", event);
    socket.send("Client Closed!");
};

socket.onerror = (error) => {
    console.log("Socket Error: ", error);
};

let tempMapID, tempImg, tempMapArtist, tempMapTitle, tempMapDiff, tempMapper, tempRankedStatus;

let tempSR, tempCS, tempAR, tempOD, tempHPDr;

let gameState;
let tempScore;
let tempAcc;
let tempCombo;
let interfaceID;

let temp300;
let temp100;
let temp50;
let temp0;
let tempGrade;

let tempPP;

let tempUsername;
let tempUID;
let tempCountry;
let tempRanks;
let tempcountryRank;
let tempPlayerPP;

let tempHP;
let tempMods;
let isHidden;

let rankingPanelSet;
let apiGetSet = false;

let tempTimeCurrent;
let tempTimeFull;
let tempFirstObj;
let tempTimeMP3;

let tempStrainBase;
let smoothOffset = 2;
let seek;
let fullTime;

let tempHitErrorArrayLength;
let OD = 0;
let tickPos;
let fullPos;
let tempAvg;
let tempTotalAvg = 0;
let tempTotalWeighted = 0;
let tempBool;

let tempURIndex;
let tempSmooth;

let tempSlotLength, tempCurrentPosition;
let leaderboardSet = 0;
let leaderboardFetch;
let ourplayerSet = 0;
let ourplayerContainer;
let ourplayerScore;

let minimodsContainerOP, tempMinimodsOP, minimodsCountOP;

let tempMapScores = [];
let playerPosition;

window.onload = function () {
    var ctx = document.getElementById("canvas").getContext("2d");
    window.myLine = new Chart(ctx, config);
};

socket.onmessage = async (event) => {
    let data = JSON.parse(event.data);

    switch (jsonData.leaderboardEnable) {
        case "1":
            document.getElementById("leaderboardx").style.opacity = 1;
            break;
        case "0":
            document.getElementById("leaderboardx").style.opacity = 0;
            break;
    }

    if (data.gameplay.name && tempUsername !== data.gameplay.name && data.menu.state === 2) {
        tempUsername = data.gameplay.name;
        username.innerHTML = tempUsername;
        await setupUser(tempUsername);
    }

    if (tempImg !== data.menu.bm.path.full) {
        tempImg = data.menu.bm.path.full;
        data.menu.bm.path.full = data.menu.bm.path.full.replace(/#/g, "%23").replace(/%/g, "%25").replace(/\\/g, "/").replace(/'/g, "%27");
        mapThumb.style.backgroundImage = `url('http://127.0.0.1:24050/Songs/${data.menu.bm.path.full}?a=${Math.random(10000)}')`;
        mapBG.style.backgroundImage = `linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)), url('http://127.0.0.1:24050/Songs/${
            data.menu.bm.path.full
        }?a=${Math.random(10000)}')`;
        rankingPanelBG.style.backgroundImage = `linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)), url('http://127.0.0.1:24050/Songs/${
            data.menu.bm.path.full
        }?a=${Math.random(10000)}')`;
        mapContainer.style.backgroundPosition = "50% 50%";
    }

    if (gameState !== data.menu.state) {
        gameState = data.menu.state;
        if (gameState !== 2) {
            upperPart.style.transform = "translateY(-400px)";

            tickPos = 0;
            tempAvg = 0;
            l300.style.width = "119.5px";
            l300.style.transform = "translateX(0)";
            l100.style.width = "209.8px";
            l100.style.transform = "translateX(0)";
            avgHitError.style.transform = "translateX(0)";

            bottom.style.transform = "translateY(300px)";

            document.getElementById("modContainer").style.transform = "translateX(-500px)";

            document.getElementById("leaderboardx").style.transform = "translateX(-400px)";

            leaderboard.innerHTML = "";
            leaderboardRank.innerHTML = "";
            leaderboardFetch = false;
            leaderboardSet = 0;
            ourplayerSet = 0;
            $("#ourplayer").remove();
        } else {
            upperPart.style.transform = "none";
            bottom.style.transform = "none";
            document.getElementById("modContainer").style.transform = "none";

            if (globalColor) {
                document.querySelectorAll("#top [id*=BG]").forEach((e) => {
                    e.style.backgroundColor = e.id === "comboBG" ? `hsl(${globalColor[1]})` : `hsl(${globalColor[0]})`;
                });

                if (document.querySelector(".ourplayerContainer"))
                    document.querySelector(
                        ".ourplayerContainer"
                    ).style.background = `linear-gradient(90deg, hsl(${globalColor[0]}) 0%, rgba(0,0,0,0) 75%)`;
                document.querySelectorAll(".rankIdx").forEach((e) => {
                    e.style.color = `hsl(${globalColor[0]})`;
                });
            }
        }
    }

    if (tempMapID !== data.menu.bm.id || tempSR !== data.menu.bm.stats.fullSR) {
        colorSet = 0;
        tempMapID = data.menu.bm.id;
        tempMapArtist = `<span style="font-size: 15px; font-weight: 100">${data.menu.bm.metadata.artist}</span>`;
        tempMapTitle = data.menu.bm.metadata.title;
        tempMapDiff = "[" + data.menu.bm.metadata.difficulty + "]";
        tempMapper = data.menu.bm.metadata.mapper;
        tempRankedStatus = data.menu.bm.rankedStatus;

        tempCS = data.menu.bm.stats.CS;
        tempAR = data.menu.bm.stats.AR;
        tempOD = data.menu.bm.stats.OD;
        tempHPDr = data.menu.bm.stats.HP;
        tempSR = data.menu.bm.stats.fullSR;

        tempFirstObj = data.menu.bm.time.firstObj;

        mapName.innerHTML = tempMapArtist + "<br>" + tempMapTitle;

        mapInfo.innerHTML = `${tempMapDiff}`;

        stats.innerHTML =
            "CS: " +
            tempCS +
            "&emsp;" +
            "AR: " +
            tempAR +
            "&emsp;" +
            "OD: " +
            tempOD +
            "&emsp;" +
            "HP: " +
            tempHPDr +
            "&emsp;" +
            "SR: " +
            tempSR +
            "*";
    }

    if (tempGrade !== data.gameplay.hits.grade.current) {
        tempGrade = data.gameplay.hits.grade.current;
    }

    if (data.gameplay.score == 0) {
    }

    if (tempScore !== data.gameplay.score) {
        tempTotalAvg = 0;
        tempTotalWeighted = 0;
        tempAvg = 0;
        tempScore = data.gameplay.score;
        score.innerHTML = tempScore;
        animation.score.update(score.innerHTML);
    }

    if (tempAcc !== data.gameplay.accuracy) {
        tempAcc = data.gameplay.accuracy;
        acc.innerHTML = tempAcc;
        animation.acc.update(acc.innerHTML);
    }

    if (fullTime !== data.menu.bm.time.mp3) {
        fullTime = data.menu.bm.time.mp3;
        onepart = 1700 / fullTime;
    }

    if (tempStrainBase !== JSON.stringify(reduceArray(data.menu.pp.strains, 100))) {
        graphRaw = reduceArray(data.menu.pp.strains, 100);
        tempLink = JSON.stringify(reduceArray(data.menu.pp.strains, 100));
        if (data.menu.pp.strains) smoothed = smooth(graphRaw, smoothOffset);
        config.data.datasets[0].data = graphRaw;
        config.data.labels = graphRaw;
        if (window.myLine) {
            window.myLine.update();
        }
    }
    if (seek !== data.menu.bm.time.current && fullTime !== undefined && fullTime !== 0) {
        seek = data.menu.bm.time.current;
        timeElapsed.innerHTML = seek < 0 ? 0 : millisToMinutesAndSeconds(seek);
        timeLeft.innerHTML = seek >= fullTime ? "-0:00" : "-" + millisToMinutesAndSeconds(fullTime - seek);
        progressBar.style.width = seek >= fullTime ? "1700px" : onepart * seek + "px";
    }
    if (tempMods !== data.menu.mods.str) {
        document.getElementById("modContainer").innerHTML = "";

        tempMods = data.menu.mods.str;

        if (tempMods.search("HD") !== -1) isHidden = true;
        else isHidden = false;

        let modsCount = tempMods.length;

        for (var i = 0; i < modsCount; i++) {
            if (tempMods.substr(i, 2) !== "NM" || tempMods.substr(i, 2) !== "TD") {
                let mods = document.createElement("div");
                mods.id = tempMods.substr(i, 2);
                mods.setAttribute("class", "mods");
                mods.style.backgroundImage = `url('./static/mods/${tempMods.substr(i, 2)}.png')`;
                mods.style.transform = `translateX(-${(i / 2) * 20}px)`;
                document.getElementById("modContainer").appendChild(mods);
            }
            i++;
        }

        if (OD !== data.menu.bm.stats.OD) {
            if (data.menu.mods.str.indexOf("DT") == -1 || data.menu.mods.str.indexOf("NC") == -1) {
                OD = data.menu.bm.stats.OD;
            } else {
                OD = (500 / 333) * data.menu.bm.stats.OD + -2210 / 333;
            }
            if (data.menu.mods.str.indexOf("HT") == -1) {
                OD = data.menu.bm.stats.OD;
            } else {
                OD = (500 / 667) * data.menu.bm.stats.OD + -2210 / 667;
            }
        }
    }
    if (tempCombo !== data.gameplay.combo.current) {
        tempCombo = data.gameplay.combo.current;
        if (data.gameplay.combo.current == data.gameplay.combo.max) {
            tempMaxCombo = data.gameplay.combo.max;
        }
        combo.innerHTML = tempCombo;
        animation.combo.update(combo.innerHTML);
    }

    if (data.gameplay.hits.hitErrorArray !== null) {
        tempSmooth = smooth(data.gameplay.hits.hitErrorArray, 4);

        if (tempHitErrorArrayLength !== tempSmooth.length) {
            tempHitErrorArrayLength = tempSmooth.length;
            for (var a = 0; a < tempHitErrorArrayLength; a++) {
                tempAvg = tempAvg * 0.9 + tempSmooth[a] * 0.1;
            }
            fullPos = -10 * OD + 199.5;
            tickPos = (data.gameplay.hits.hitErrorArray[tempHitErrorArrayLength - 1] / fullPos) * 145;
            avgHitError.style.transform = `translateX(${(tempAvg / fullPos) * 150}px)`;
            l100.style.width = `${((-8 * OD + 139.5) / fullPos) * 300}px`;
            l100.style.transform = `translateX(${(209.8 - ((-8 * OD + 139.5) / fullPos) * 300) / 2}px)`;
            l300.style.width = `${((-6 * OD + 79.5) / fullPos) * 300}px`;
            l300.style.transform = `translateX(${(119.5 - ((-6 * OD + 79.5) / fullPos) * 300) / 2}px)`;
            let tick = document.createElement("div");
            tick.id = `tick${tempHitErrorArrayLength}`;
            tick.setAttribute("class", "tick");
            tick.style.opacity = 1;
            tick.style.transform = `translateX(${tickPos}px)`;
            document.getElementById("URbar").appendChild(tick);

            function fade() {
                tick.style.opacity = 0;
            }

            function remove() {
                document.getElementById("URbar").removeChild(tick);
            }
            setTimeout(fade, 2000);
            setTimeout(remove, 2500);
        }
    }

    if (tempURIndex !== data.gameplay.hits.unstableRate) {
        tempURIndex = data.gameplay.hits.unstableRate;
        URIndex.innerHTML = tempURIndex;
        animation.URIndex.update(URIndex.innerHTML);
    }

    if (temp300 !== data.gameplay.hits[300]) {
        temp300 = data.gameplay.hits[300];
        h300.innerHTML = `<span style="font-size: 15px;">PF</span><br>${temp300}`;
    }
    if (temp100 !== data.gameplay.hits[100]) {
        temp100 = data.gameplay.hits[100];
        h100.innerHTML = `<span style="font-size: 15px">GR</span><br>${temp100}`;
    }
    if (temp50 !== data.gameplay.hits[50]) {
        temp50 = data.gameplay.hits[50];
        h50.innerHTML = `<span style="font-size: 15px">GD</span><br>${temp50}`;
    }
    if (temp0 !== data.gameplay.hits[0]) {
        temp0 = data.gameplay.hits[0];
        h0.innerHTML = `<span style="font-size: 15px">X</span><br>${temp0}`;
    }
    if (tempPP !== data.gameplay.pp.current) {
        tempPP = data.gameplay.pp.current;
        pp.innerHTML = tempPP;
        animation.pp.update(pp.innerHTML);
    }

    if (tempTimeCurrent !== data.menu.bm.time.current) {
        tempTimeCurrent = data.menu.bm.time.current;
        tempTimeFull = data.menu.bm.time.full;
        tempTimeMP3 = data.menu.bm.time.mp3;
        interfaceID = data.settings.showInterface;

        if (gameState == 2) {
            upperPart.style.transform = "none";

            if (jsonData.leaderboardTab === 1)
                document.getElementById("leaderboardx").style.opacity = data.gameplay.leaderboard.isVisible === true ? 0 : 1;

            setupMapScores(tempMapID, tempUsername);

            if (tempSlotLength !== tempMapScores.length) {
                tempSlotLength = tempMapScores.length;
            }

            document.getElementById("leaderboardx").style.transform = "none";

            if (!ourplayerSet && jsonData.leaderboardEnable === 1) {
                ourplayerSet = 1;
                ourplayerContainer = document.createElement("div");
                ourplayerContainer.id = "ourplayer";
                ourplayerContainer.setAttribute("class", "ourplayerContainer");

                ourplayerScore = null;
                ourplayerScore = document.createElement("div");
                ourplayerScore.id = "ourplayerScore";
                ourplayerScore.style.fontSize = "15px";
                ourplayerScore.style.fontFamily = "Torus";
                ourplayerScore.style.width = "100px";

                ourplayerContainer.appendChild(ourplayerScore);
                leaderboardx.appendChild(ourplayerContainer);

                animation.ourplayerScore = new CountUp("ourplayerScore", 0, 0, 0, 0.2, {
                    useEasing: true,
                    useGrouping: true,
                    separator: ",",
                    decimal: ".",
                });
            }

            if (!tempUID) tempUID = "8266808";

            ourplayerScore.innerHTML = tempScore;
            animation.ourplayerScore.update(ourplayerScore.innerHTML);

            if (!ourplayerScore.innerHTML.includes(",")) ourplayerScore.innerHTML = new Intl.NumberFormat().format(Number(data.gameplay.score));

            if (document.getElementById("ourplayer"))
                if (playerPosition > 5) {
                    leaderboard.style.transform = `translateY(${-(playerPosition - 6) * 30}px)`;

                    document.getElementById("leaderboardRank").style.transform = `translateY(${-(playerPosition - 6) * 30}px)`;

                    document.getElementById("ourplayer").style.transform = `none`;
                } else {
                    leaderboard.style.transform = "translateY(0)";
                    document.getElementById("leaderboardRank").style.transform = "translateY(0)";
                    document.getElementById("ourplayer").style.transform = `translateY(-${(6 - playerPosition) * 30}px)`;
                }

            if (tempSlotLength > 0)
                for (var i = 1; i <= tempSlotLength; i++) {
                    if (i >= playerPosition && playerPosition !== 0 && document.getElementById(`slot${i}`)) {
                        document.getElementById(`slot${i}`).style.transform = `translateY(30px)`;
                    }
                }

            if (interfaceID == 1 && gameState == 2) {
                upperPart.style.transform = "translateY(-200px)";
                bottom.style.transform = "translateY(300px)";
            } else {
                upperPart.style.transform = "none";
                bottom.style.transform = "none";
            }
        }
    }

    if (tempMapScores.length > 0) if (tempScore >= tempMapScores[playerPosition - 2]) playerPosition--;

    if (data.gameplay.hp.smooth > 0) {
        let hpRate = (data.gameplay.hp.smooth / 200) * 0.9838 * 100;
        hp.style.clipPath = `polygon(0 0, ${hpRate}% 0, ${hpRate}% 100%, 0 100%)`;
    } else {
        hp.style.clipPath = `polygon(0 0, 98.38% 0, 98.38% 100%, 0 100%)`;
    }
};

let config = {
    type: "bar",
    data: {
        labels: [],
        datasets: [
            {
                borderWidth: "0",
                backgroundColor(c) {
                    let alpha = (c.dataset.data[c.dataIndex] / Math.max.apply(null, graphRaw)) * 0.6;
                    return `rgba(255, 255, 255, ${alpha})`;
                },
                data: [],
                fill: true,
                minBarLength: 100,
                barPercentage: 1.0,
                categoryPercentage: 1.0,
            },
        ],
    },
    options: {
        tooltips: { enabled: false },
        legend: {
            display: false,
        },
        responsive: false,
        scales: {
            x: {
                display: false,
            },
            y: {
                display: false,
            },
        },
    },
};

let configSecond = {
    type: "bar",
    data: {
        labels: [],
        datasets: [
            {
                borderColor: "rgba(0, 0, 0, 0)",
                borderWidth: "0",
                backgroundColor: "rgba(255, 255, 255, 1)",
                data: [],
                fill: true,
                minBarLength: 100,
                barPercentage: 1.0,
                categoryPercentage: 1.0,
            },
        ],
    },
    options: {
        tooltips: { enabled: false },
        legend: {
            display: false,
        },
        responsive: false,
        scales: {
            x: {
                display: false,
            },
            y: {
                display: false,
            },
        },
    },
};

function reduceArray(array, newSize) {
    const returnArray = [];
    const valuesToSum = array.length / newSize;
    for (let i = 0; i < array.length; i += valuesToSum) {
        let sum = 0;
        let j;
        let start_i = Math.floor(i);
        for (j = start_i; j < Math.min(start_i + valuesToSum, array.length); j++) {
            sum += array[j];
        }
        returnArray.push(sum / (j - start_i));
    }
    return returnArray;
}

function millisToMinutesAndSeconds(millis) {
    var minutes = Math.floor(millis / 60000);
    var seconds = ((millis % 60000) / 1000).toFixed(0);
    return seconds == 60 ? minutes + 1 + ":00" : minutes + ":" + (seconds < 10 ? "0" : "") + seconds;
}

function brightnessCheck(element, rgb) {
    let brightness = 0.21 * rgb.r + 0.72 * rgb.g + 0.07 * rgb.b;
    if (brightness > 190) {
        element.style.color = "#161616";
        element.style.textShadow = "0 2px 3px rgba(0, 0, 0, 0.5)";
    } else {
        element.style.color = "white";
        element.style.textShadow = "0 2px 5px rgba(0, 0, 0, 0.6);";
    }
}

async function setupUser(name) {
    let userData = await postUserID(name);

    const avatarColor = userData.colorData;

    if (Object.keys(userData).length <= 1) {
        userData = {
            user: {
                id: "gamer",
                username: `${name}`,
                statistics: {
                    global_rank: 0,
                    pp: 0,
                    country_rank: 0,
                },
                country_code: "__",
            },
        };
    }

    tempUID = userData.user.id;

    tempCountry = userData.user.country_code;
    tempCountry =
        tempCountry
            .split("")
            .map((char) => 127397 + char.charCodeAt())[0]
            .toString(16) +
        "-" +
        tempCountry
            .split("")
            .map((char) => 127397 + char.charCodeAt())[1]
            .toString(16);
    tempRanks = userData.user.statistics.global_rank;
    tempcountryRank = userData.user.statistics.country_rank;
    tempPlayerPP = userData.user.statistics.pp;

    if (tempUID !== "gamer") {
        ava.style.backgroundImage = `url('https://a.ppy.sh/${tempUID}')`;
    } else {
        ava.style.backgroundImage = "url('./static/gamer.png')";
    }

    country.style.backgroundImage = `url('https://osu.ppy.sh/assets/images/flags/${tempCountry}.svg')`;

    ranks.innerHTML = `#${tempRanks} (#${tempcountryRank} ${userData.user.country_code})`;

    playerPP.innerHTML = Math.round(tempPlayerPP) + "pp";

    if (avatarColor) {
        globalColor = avatarColor;
        document.querySelectorAll("#top [id*=BG]").forEach((e) => {
            e.style.backgroundColor = e.id === "comboBG" ? `hsl(${globalColor[1]},0.6)` : `hsl(${globalColor[0]})`;
        });

        document.querySelector(".ourplayerContainer").style.background = `linear-gradient(90deg, hsl(${globalColor[0]}) 0%, rgba(0,0,0,0) 75%)`;
        document.querySelectorAll(".rankIdx").forEach((e) => {
            e.style.color = `hsl(${globalColor[0]})`;
        });
    }
}

async function fetchWebBancho(md5, beatmapId) {
    try {
        const data = (
            await axios.get("/osu-osz2-getscores.php", {
                baseURL: "https://osu.ppy.sh/web",
                headers: {
                    "User-Agent": "osu!",
                    Host: "osu.ppy.sh",
                    "Accept-Encoding": "gzip, deflate",
                },
                params: {
                    s: 0,
                    vv: 4,
                    v: 4,
                    c: md5,
                    m: 0,
                    i: beatmapId,
                    mods: 0,
                    us: uname,
                    ha: pwd,
                },
            })
        )["data"];
        return data.length !== 0 ? data[0] : null;
    } catch (error) {
        console.error(error);
    }
}

async function setupMapScores(beatmapID) {
    if (leaderboardFetch === false) {
        leaderboardFetch = true;

        let data = await getBeatmapScores(beatmapID);

        data = data.filter((val, idx, arr) => {
            return val.username !== tempUsername;
        });

        if (data) {
            tempSlotLength = data.length;
            playerPosition = data.length + 1;
        } else {
            tempSlotLength = 0;
            playerPosition = 1;
        }

        for (let i = 1; i <= tempSlotLength; i++) {
            let rankNum = document.createElement("div");
            rankNum.setAttribute("class", "rankIdx");
            rankNum.innerHTML = `#${i}`;

            document.getElementById("leaderboardRank").appendChild(rankNum);
        }

        for (var i = tempSlotLength; i > 0; i--) {
            tempMapScores[i - 1] = parseInt(data[i - 1].score);

            let playerContainer = document.createElement("div");
            playerContainer.id = `slot${i}`;
            playerContainer.setAttribute("class", "playerContainer");
            playerContainer.style.top = `${(i - 1) * 30}px`;

            let playerAvatarLB = `<div id="lb_ava${i}" style="background-image: url('https://a.ppy.sh/${
                data[i - 1].user_id
            }')" class="leaderboardAvatar"></div>`;

            let playerNameLB = `<div id="lb_name${i}" style="width: 180px; color: #ffffff; filter: drop-shadow(0 0 5px rgba(0, 0, 0 ,0))">${
                data[i - 1].username
            }</div>`;

            let playerScoreLB = `<div id="lb_score${i}" style="font-size: 15px; font-family: Torus; width: 100px; color: #ffffff; filter: drop-shadow(0 0 5px rgba(0, 0, 0 ,0))">${new Intl.NumberFormat().format(
                Number(data[i - 1].score)
            )}</div>`;

            playerContainer.innerHTML = playerScoreLB;
            document.getElementById("leaderboard").appendChild(playerContainer);
        }

        if (document.getElementsByClassName("ourplayerContainer") !== undefined)
            document.getElementsByClassName(
                "ourplayerContainer"
            )[0].style.background = `linear-gradient(90deg, hsl(${globalColor[0]}) 0%, rgba(0,0,0,0) 75%)`;
        document.querySelectorAll(".rankIdx").forEach((e) => {
            e.style.color = `hsl(${globalColor[0]})`;
        });
    }
}

async function getBeatmapScores(beatmap_id) {
    try {
        const data = (
            await axios.get(`/${beatmap_id}/scores`, {
                baseURL: "https://tryz.vercel.app/api/b",
                params: {
                    passphrase: jsonData.passphrase,
                },
            })
        ).data;
        return data;
    } catch (error) {
        console.error(error);
    }
}

async function postUserID(id) {
    try {
        let data = null;
        await axios.get(`http://tryz.vercel.app/api/c/${id}`).then((response) => {
            data = response.data;
        });
        return data;
    } catch (error) {
        console.error(error);
    }
}

const accuracyCalc = (h300, h100, h50, h0) => {
    let accuracy = ((h300 + h100 / 3 + h50 / 6) / (h300 + h100 + h50 + h0)) * 100;
    return accuracy.toFixed(2);
};

const grader = (h300, h100, h50, h0, isHD) => {
    // console.log(isHD);
    let acc = accuracyCalc(h300, h100, h50, h0);
    let maxCombo = h300 + h100 + h50 + h0;
    switch (true) {
        case acc == 100 || maxCombo === 0:
            if (isHD === -1) {
                return `<div id="gradeOurplayer" style="width: 50px; color: #de3950; filter: drop-shadow(0 0 5px #de3950)">X</div>`;
                break;
            }
            return `<div id="gradeOurplayer"  style="width: 50px; color: #ffffff; filter: drop-shadow(0 0 5px #ffffff)">X</div>`;
            break;
        case acc > 90 && h50 / maxCombo < 0.01 && h0 === 0:
            if (isHD === -1) {
                return `<div id="gradeOurplayer"  style="width: 50px; color: #f2d646; filter: drop-shadow(0 0 5px #f2d646)">S</div>`;
                break;
            }
            return `<div id="gradeOurplayer"  style="width: 50px; color: #ffffff; filter: drop-shadow(0 0 5px #ffffff)">S</div>`;
            break;
        case (acc > 80 && acc <= 90 && h0 === 0) || h300 / maxCombo > 0.9:
            return `<div id="gradeOurplayer"  style="width: 50px; color: #46f26e; filter: drop-shadow(0 0 5px #46f26e)">A</div>`;
            break;
        case (acc > 70 && acc <= 80 && h0 === 0) || h300 / maxCombo > 0.8:
            return `<div id="gradeOurplayer"  style="width: 50px; color: #469cf2; filter: drop-shadow(0 0 5px #469cf2)">B</div>`;
            break;
        case h300 / maxCombo > 0.6 && h300 / maxCombo <= 0.8:
            return `<div id="gradeOurplayer"  style="width: 50px; color: #9f46f2; filter: drop-shadow(0 0 5px #9f46f2)">C</div>`;
            break;
        case h300 / maxCombo <= 0.6:
            return `<div id="gradeOurplayer"  style="width: 50px; color: #ff0000; filter: drop-shadow(0 0 5px #ff0000)">D</div>`;
            break;
    }
};

const grader_text = (h300, h100, h50, h0, isHD) => {
    // console.log(isHD);
    let acc = accuracyCalc(h300, h100, h50, h0);
    let maxCombo = h300 + h100 + h50 + h0;
    switch (true) {
        case acc == 100 || maxCombo === 0:
            if (isHD === -1) {
                return `X`;
                break;
            }
            return `XH`;
            break;
        case acc > 90 && h50 / maxCombo < 0.01 && h0 === 0:
            if (isHD === -1) {
                return `S`;
                break;
            }
            return `SH`;
            break;
        case (acc > 80 && acc <= 90 && h0 === 0) || h300 / maxCombo > 0.9:
            return `A`;
            break;
        case (acc > 70 && acc <= 80 && h0 === 0) || h300 / maxCombo > 0.8:
            return `B`;
            break;
        case h300 / maxCombo > 0.6 && h300 / maxCombo <= 0.8:
            return `C`;
            break;
        case h300 / maxCombo <= 0.6:
            return `D`;
            break;
    }
};

const setLeaderboardTrue = () => {
    leaderboardFetch = true;
};
